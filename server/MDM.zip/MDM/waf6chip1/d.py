
with open("F:\project\MDM\waf6chip1\kristalsos_waf6chip1~DT13p_W520_L6~soi_dc_idvd~301K.mdm") as f:
    print(f.readlines())